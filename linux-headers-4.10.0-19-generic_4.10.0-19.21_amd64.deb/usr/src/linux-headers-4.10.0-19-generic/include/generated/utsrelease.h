#define UTS_RELEASE "4.10.0-19-generic"
#define UTS_UBUNTU_RELEASE_ABI 19
