/* This file is auto generated, version 21 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#21 SMP Sun Oct 1 16:17:00 CEST 2017"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu-wifibroadcast"
#define LINUX_COMPILER "gcc version 6.3.0 20170406 (Ubuntu 6.3.0-12ubuntu2) "
